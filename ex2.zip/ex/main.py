from ex.model.Cliente import *
from ex.model.Banco import *

if __name__ == "__main__":
    banco = Banco()
    banco.operacion()
    banco.total()